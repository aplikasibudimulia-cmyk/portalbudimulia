import{D as r,q as F,T as u,p as st,R as ie,u as e}from"./index-NMjYE8Pj.js";import{e as nt}from"./presensiSessionUtils-DrjMME_f.js";import lt from"./PresensiMatriksRekapSection-CJVcqfSZ.js";import{s as re}from"./DashboardGuru-CSXMVdLj.js";import{o as oe,j as it,C as Me,X as Le,Y as De,u as de,i as rt,a as ot,B as dt,c as ct}from"./BarChart-RMipMOFA.js";import{a as ht,P as mt}from"./PieChart-CWugyJVL.js";import"./useConfirm-Cy2BqTuZ.js";import"./CollapsibleSection-CorbT60i.js";import"./whatsappHelper-CgNFAjS0.js";import"./index-jaNiXJHr.js";import"./ExportKontakModal-CPm6YaCV.js";import"./fileDownloader-Bs_csy6P.js";import"./xlsx-BCVDnt67.js";function Dt({session:M,activeTa:j,filterKelas:x}){const[q,ce]=r.useState("daily"),[k,$e]=r.useState(F()),[Ae,Ce]=r.useState([]),[T,ze]=r.useState([]),[v,Pe]=r.useState([]),[E,he]=r.useState([]),[me,Ie]=r.useState([]),[ue,Te]=r.useState([]),[He,G]=r.useState(!0),[J,xe]=r.useState(!1),[R,Be]=r.useState(!1),[W,Ke]=r.useState(!1),[pe,ge]=r.useState(!1),[fe,be]=r.useState(!1),[C,Ee]=r.useState(null),z=r.useCallback(async()=>{const t=F();try{const[{data:s},{data:n}]=await Promise.all([u.from("pengaturan_sekolah").select("setting_key, setting_value").not("setting_key","like","kartu_%"),u.from("sesi_presensi").select("*").eq("tanggal",t).maybeSingle()]),o=nt({settings:s||[],sesiPresensiRow:n,dateNow:st()});Ee(o),Be(o.isSesiMasukAktif),Ke(o.isSesiPulangAktif)}catch(s){console.warn("Gagal memuat status sesi presensi piket:",s)}},[]);r.useEffect(()=>{z();const t=u.channel("piket-session-sync").on("postgres_changes",{event:"*",schema:"public",table:"pengaturan_sekolah"},()=>{z()}).on("postgres_changes",{event:"*",schema:"public",table:"sesi_presensi"},()=>{z()}).subscribe();return()=>u.removeChannel(t)},[z]);const Re=async()=>{const t=!R;ge(!0);const s=F();try{t?await Promise.all([u.from("sesi_presensi").upsert({tanggal:s,dibuka_oleh:(M==null?void 0:M.id)||"piket",dibuka_pada:new Date().toISOString()},{onConflict:"tanggal"}),u.from("pengaturan_sekolah").delete().eq("setting_key",`sesi_selesai_${s}`)]):await Promise.all([u.from("sesi_presensi").delete().eq("tanggal",s),u.from("pengaturan_sekolah").delete().eq("setting_key",`sesi_selesai_${s}`)]),await z()}catch(n){console.error("Gagal update status sesi masuk:",n)}finally{ge(!1)}},We=async()=>{const t=!W;be(!0);const s=F();try{t?await Promise.all([u.from("pengaturan_sekolah").upsert({setting_key:"presensi_pulang_aktif",setting_value:"true"},{onConflict:"setting_key"}),u.from("pengaturan_sekolah").upsert({setting_key:"presensi_pulang_tanggal",setting_value:s},{onConflict:"setting_key"})]):await u.from("pengaturan_sekolah").upsert({setting_key:"presensi_pulang_aktif",setting_value:"false"},{onConflict:"setting_key"}),await z()}catch(n){console.error("Gagal update status presensi pulang:",n)}finally{be(!1)}};r.useEffect(()=>{ke()},[k,j,x]);const y=ie.useRef(null);ie.useEffect(()=>{y.current=ke}),r.useEffect(()=>{const t=u.channel("realtime_piket_dashboard").on("postgres_changes",{event:"*",schema:"public",table:"presensi_harian"},s=>{var o;const n=s.new||s.old;n&&n.tanggal===k&&((o=y.current)==null||o.call(y,!0))}).subscribe();return()=>u.removeChannel(t)},[k,x]),r.useEffect(()=>{const t=setInterval(()=>{var s;(s=y.current)==null||s.call(y,!0)},6e4);return()=>clearInterval(t)},[k,x]);const _=ie.useRef({activeTaId:null,filterKelas:null,siswaMap:{},fullSiswaMap:{},nisnList:[],siswaData:[],semuaSiswaFullDB:[]}),ke=async(t=!1)=>{if(t||G(!0),typeof navigator!="undefined"&&!navigator.onLine){t||G(!1);return}try{const s=j==null?void 0:j.id,n=JSON.stringify(x),o=_.current.activeTaId!==s||JSON.stringify(_.current.filterKelas)!==n||_.current.siswaData.length===0;let p=[],N={},g=[],S=[],$={};if(o){let i=0,c=999,h=!0;for(;h&&!(typeof navigator!="undefined"&&!navigator.onLine);)try{let d=u.from("siswa_lengkap").select("nisn, nama_lengkap, kelas").eq("is_aktif",!0).range(i,c);x&&x.length>0&&(d=d.in("kelas",x));const{data:m,error:B}=await d;if(B){console.error(B);break}!m||m.length===0?h=!1:(p=[...p,...m],m.length<1e3?h=!1:(i+=1e3,c+=1e3))}catch(d){console.warn("[PiketDashboard] Error fetching siswaData:",d);break}if(p.length>0){ze(p);const d=re([...new Set(p.map(m=>m.kelas).filter(Boolean))]);Ce(d),p.forEach(m=>{N[m.nisn]=m.kelas,g.push(m.nisn)})}for(i=0,c=999,h=!0;h&&!(typeof navigator!="undefined"&&!navigator.onLine);)try{const{data:d,error:m}=await u.from("siswa_lengkap").select("nisn, kelas").eq("is_aktif",!0).range(i,c);if(m){console.error(m);break}!d||d.length===0?h=!1:(S=[...S,...d],d.length<1e3?h=!1:(i+=1e3,c+=1e3))}catch(d){console.warn("[PiketDashboard] Error fetching semuaSiswaFullDB:",d);break}if(S.length>0){const d=re([...new Set(S.map(m=>m.kelas).filter(Boolean))]);Te(d),S.forEach(m=>{$[m.nisn]=m.kelas})}_.current={activeTaId:s,filterKelas:x,siswaMap:N,fullSiswaMap:$,nisnList:g,siswaData:p,semuaSiswaFullDB:S}}else p=_.current.siswaData,N=_.current.siswaMap,g=_.current.nisnList,S=_.current.semuaSiswaFullDB,$=_.current.fullSiswaMap;if(typeof navigator!="undefined"&&!navigator.onLine)return;try{const{data:i}=await u.from("presensi_harian").select("siswa_nisn, kelas, status, tipe").eq("tanggal",k).range(0,2999);if(i){const c=i.filter(h=>h.tipe!=="pulang").map(h=>({...h,kelas:$[h.siswa_nisn]||h.kelas}));Ie(c)}}catch(i){console.warn("[PiketDashboard] Error fetching presensiHariIniFull:",i)}try{let i=u.from("presensi_harian").select("*").eq("tanggal",k).range(0,2999);x&&x.length>0&&g.length>0?i=i.in("siswa_nisn",g):x&&x.length>0&&(i=i.in("siswa_nisn",["0000000000"]));const{data:c}=await i;if(c){const h=c.filter(d=>d.tipe!=="pulang").map(d=>({...d,kelas:N[d.siswa_nisn]||d.kelas}));Pe(h)}}catch(i){console.warn("[PiketDashboard] Error fetching presensiHariIni:",i)}const L=new Date(k);L.setDate(L.getDate()-7);const Ne=L.toLocaleDateString("en-CA");let f=[],A=0,P=999,H=!0;for(;H&&!(typeof navigator!="undefined"&&!navigator.onLine);)try{let i=u.from("presensi_harian").select("siswa_nisn, kelas, status, tipe, tanggal").gte("tanggal",Ne).lte("tanggal",k).range(A,P);x&&x.length>0&&g.length>0?i=i.in("siswa_nisn",g):x&&x.length>0&&(i=i.in("siswa_nisn",["0000000000"]));const{data:c,error:h}=await i;if(h){console.error(h);break}!c||c.length===0?H=!1:(f=[...f,...c],c.length<1e3?H=!1:(A+=1e3,P+=1e3))}catch(i){console.warn("[PiketDashboard] Error fetching presensiMingguanDB:",i);break}if(f.length>0){const i=f.filter(c=>c.tipe!=="pulang").map(c=>({...c,kelas:N[c.siswa_nisn]||c.kelas}));he(i)}else he([])}catch(s){console.error(s)}finally{G(!1)}},we=t=>t.split(" ").map(s=>s[0]).join("").substring(0,2).toUpperCase(),Oe=T.length,Fe=v.filter(t=>t.status==="H"||t.status==="T").length,je=v.filter(t=>t.status==="T").length,qe=v.filter(t=>t.status==="S"||t.status==="I").length,Ge=v.filter(t=>t.status==="A").length,Je=r.useMemo(()=>{const t=[];for(let s=6;s>=0;s--){const n=new Date(k);n.setDate(n.getDate()-s);const o=n.toLocaleDateString("en-CA"),p=n.toLocaleDateString("id-ID",{month:"short",day:"numeric"}),N=E.filter(g=>g.tanggal===o&&(g.status==="H"||g.status==="T")).length;t.push({dateStr:o,label:p,total:N})}return t},[E,k]),Ue=r.useMemo(()=>ue.map(t=>{const s=me.filter(n=>n.kelas===t&&(n.status==="H"||n.status==="T")).length;return{kelas:t,hadir:s}}),[ue,me]),O=r.useMemo(()=>[{name:"Sakit",value:v.filter(t=>t.status==="S").length,color:"#3b82f6"},{name:"Izin",value:v.filter(t=>t.status==="I").length,color:"#a855f7"},{name:"Alpha",value:v.filter(t=>t.status==="A").length,color:"#f43f5e"},{name:"Terlambat",value:je,color:"#f97316"}].filter(t=>t.value>0),[v,je]),ve=O.reduce((t,s)=>t+s.value,0),ye=r.useMemo(()=>{const t={};return E.forEach(n=>{(n.status==="H"||n.status==="T")&&(t[n.siswa_nisn]=(t[n.siswa_nisn]||0)+1)}),Object.entries(t).map(([n,o])=>({nisn:n,count:o})).sort((n,o)=>o.count-n.count).slice(0,5).map(n=>{const o=T.find(p=>p.nisn===n.nisn);return{...n,nama:(o==null?void 0:o.nama_lengkap)||n.nisn,kelas:(o==null?void 0:o.kelas)||"-",percentage:Math.min(Math.round(n.count/7*100),100)}})},[E,T]),U=r.useMemo(()=>{const t=new Set(v.map(s=>s.siswa_nisn));return T.filter(s=>!t.has(s.nisn))},[T,v]),Ve=r.useCallback(async()=>{xe(!0);try{const{data:t}=await u.from("pengaturan_sekolah").select("setting_key, setting_value").not("setting_key","like","kartu_%"),s={};t&&t.forEach(a=>{s[a.setting_key]=a.setting_value});const n=s.nama_sekolah||"SMP BUDI MULIA JAKARTA",o=s.alamat_sekolah||"Jakarta",p=s.telepon_sekolah||"",N=s.website_sekolah||"",{data:g}=await u.from("siswa_lengkap").select("nisn, nama_lengkap, kelas").eq("is_aktif",!0).order("kelas").order("nama_lengkap"),{data:S}=await u.from("presensi_harian").select("siswa_nisn, status, kelas, waktu, tipe").eq("tanggal",k),$={};g&&g.forEach(a=>{$[a.nisn]=a});const L={};S&&S.forEach(a=>{if(a.tipe==="pulang")return;const l=$[a.siswa_nisn];l&&(L[a.siswa_nisn]={...a,kelas:l.kelas,nama:l.nama_lengkap})});const f=re([...new Set((g||[]).map(a=>a.kelas).filter(Boolean))]).map(a=>{const l=(g||[]).filter(le=>le.kelas===a),w=l.length;let b=0,D=0,ae=0,se=0,ne=0;l.forEach(le=>{const I=L[le.nisn];I&&(I.status==="H"?b++:I.status==="T"?(b++,D++):I.status==="S"?ae++:I.status==="I"?se++:I.status==="A"&&ne++)});const at=ae+se+ne;return{kelas:a,totalSiswa:w,hadir:b,terlambat:D,sakit:ae,izin:se,alpa:ne,tidakHadir:at}}),A=Object.values(L).filter(a=>a.status==="T").sort((a,l)=>a.kelas.localeCompare(l.kelas)||a.nama.localeCompare(l.nama)),P=Object.values(L).filter(a=>a.status==="S"||a.status==="I"||a.status==="A").sort((a,l)=>a.kelas.localeCompare(l.kelas)||a.nama.localeCompare(l.nama)),H=f.reduce((a,l)=>a+l.totalSiswa,0),i=f.reduce((a,l)=>a+l.hadir,0),c=f.reduce((a,l)=>a+l.terlambat,0),h=f.reduce((a,l)=>a+l.sakit,0),d=f.reduce((a,l)=>a+l.izin,0),m=f.reduce((a,l)=>a+l.alpa,0),B=f.reduce((a,l)=>a+l.tidakHadir,0),Se=new Date(k+"T00:00:00"),Qe=["Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu"][Se.getDay()],V=Se.toLocaleDateString("id-ID",{day:"numeric",month:"long",year:"numeric"}),Ze=(M==null?void 0:M.nama_guru)||"",_e=Math.ceil(f.length/2),xt=f.slice(0,_e),pt=f.slice(_e),Y=Math.ceil(A.length/2),X=A.slice(0,Y),Q=A.slice(Y),Z=P.filter(a=>a.status==="S"),ee=P.filter(a=>a.status==="I"),te=P.filter(a=>a.status==="A"),et=Math.max(Z.length,ee.length,te.length,1),tt=`<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Laporan Piket Harian - ${V}</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: 'Times New Roman', Times, serif;
    font-size: 11pt;
    color: #000;
    background: #fff;
  }
  @page {
    size: A4;
    margin: 1.8cm 2cm 1.8cm 2.5cm;
  }
  @media print {
    body { margin: 0; }
    .page-break { page-break-before: always; }
    .no-break { page-break-inside: avoid; }
  }
  .page { width: 100%; }

  /* Header */
  .header-table { width: 100%; border-collapse: collapse; border: 1.5px solid #000; margin-bottom: 6pt; }
  .header-table td { padding: 6pt 8pt; vertical-align: middle; }
  .header-table td:first-child { width: 65%; border-right: 1.5px solid #000; }
  .school-name { font-size: 14pt; font-weight: bold; text-transform: uppercase; }
  .school-sub { font-size: 9.5pt; }
  .doc-info { font-size: 9pt; line-height: 1.7; }

  /* Title */
  .title-block { text-align: center; margin: 10pt 0 6pt; }
  .title-main { font-size: 13pt; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; }
  .title-sub { font-size: 10pt; font-weight: bold; }
  .underline-line { border-bottom: 1.5px solid #000; display: block; width: 100%; margin: 2pt 0; }

  /* Info row */
  .info-row { font-size: 10.5pt; margin: 6pt 0 10pt; font-weight: bold; }
  .info-row span { display: inline-block; border-bottom: 1px solid #000; min-width: 200pt; padding: 0 4pt; }

  /* Tables */
  table.data-table { width: 100%; border-collapse: collapse; font-size: 9.5pt; margin-bottom: 8pt; }
  table.data-table th, table.data-table td {
    border: 1px solid #000;
    padding: 3pt 5pt;
    vertical-align: middle;
  }
  table.data-table th {
    background: #f0f0f0;
    font-weight: bold;
    text-align: center;
  }
  table.data-table td.num { text-align: center; width: 24pt; }
  table.data-table td.center { text-align: center; }
  table.data-table td.kelas-cell { text-align: center; width: 48pt; }
  table.data-table td.status-cell { text-align: center; width: 36pt; font-weight: bold; }
  table.data-table tr.total-row td { font-weight: bold; background: #f8f8f8; }

  /* Section title */
  .section-title { font-size: 10pt; font-weight: bold; margin: 10pt 0 4pt; text-decoration: underline; }

  /* Signature */
  .signature-table { width: 100%; border-collapse: collapse; margin-top: 14pt; }
  .signature-table td { width: 50%; padding: 6pt 10pt; vertical-align: top; text-align: center; font-size: 10pt; }
  .signature-space { height: 44pt; }
  .signature-name { border-top: 1px solid #000; display: inline-block; min-width: 140pt; margin-top: 2pt; padding-top: 2pt; }

  /* Empty cell */
  td.empty { background: #fff; }
</style>
</head>
<body>
<div class="page">

  <!-- HEADER -->
  <table class="header-table">
    <tr>
      <td>
        <div class="school-name">${n}</div>
        ${o?`<div class="school-sub">${o}</div>`:""}
        ${p||N?`<div class="school-sub">${[p?"Telp. "+p:"",N].filter(Boolean).join("  |  ")}</div>`:""}
      </td>
      <td>
        <div class="doc-info">
          No. Dokumen&nbsp;&nbsp;: FR-PIKET-01<br>
          Revisi&emsp;&emsp;&emsp;&emsp;: 00<br>
          Berlaku Sejak : Juli 2026
        </div>
      </td>
    </tr>
  </table>

  <!-- TITLE -->
  <div class="title-block">
    <div class="title-main">Laporan Piket Harian</div>
  </div>

  <!-- HARI/TANGGAL -->
  <div class="info-row">
    HARI / TANGGAL : <span>${Qe} / ${V}</span>
  </div>

  <!-- REKAP PER KELAS -->
  <div class="section-title">Rekapitulasi Kehadiran Siswa per Kelas</div>
  <table class="data-table">
    <thead>
      <tr>
        <th>No.</th>
        <th>Kelas</th>
        <th>Jml Siswa</th>
        <th>Hadir</th>
        <th>Terlambat</th>
        <th>Sakit (S)</th>
        <th>Izin (I)</th>
        <th>Alpa (A)</th>
        <th>Tdk Hadir</th>
      </tr>
    </thead>
    <tbody>
      ${f.map((a,l)=>`
      <tr>
        <td class="num">${l+1}.</td>
        <td class="kelas-cell">${a.kelas}</td>
        <td class="center">${a.totalSiswa}</td>
        <td class="center">${a.hadir}</td>
        <td class="center">${a.terlambat>0?a.terlambat:"-"}</td>
        <td class="center">${a.sakit>0?a.sakit:"-"}</td>
        <td class="center">${a.izin>0?a.izin:"-"}</td>
        <td class="center">${a.alpa>0?a.alpa:"-"}</td>
        <td class="center">${a.tidakHadir>0?a.tidakHadir:"-"}</td>
      </tr>`).join("")}
      <tr class="total-row">
        <td colspan="2" class="center">TOTAL</td>
        <td class="center">${H}</td>
        <td class="center">${i}</td>
        <td class="center">${c>0?c:"-"}</td>
        <td class="center">${h>0?h:"-"}</td>
        <td class="center">${d>0?d:"-"}</td>
        <td class="center">${m>0?m:"-"}</td>
        <td class="center">${B>0?B:"-"}</td>
      </tr>
    </tbody>
  </table>

  <!-- SISWA TERLAMBAT -->
  <div class="section-title">Siswa Terlambat</div>
  ${A.length===0?'<table class="data-table"><thead><tr><th>No.</th><th>Kelas</th><th>Nama Siswa</th></tr></thead><tbody><tr><td class="num">-</td><td class="center">-</td><td style="text-align:center;color:#666;"><em>Tidak ada siswa terlambat</em></td></tr></tbody></table>':`<table class="data-table">
    <thead>
      <tr>
        <th style="width:28pt">No.</th>
        <th style="width:52pt">Kelas</th>
        <th>Nama Siswa</th>
        <th style="width:28pt">No.</th>
        <th style="width:52pt">Kelas</th>
        <th>Nama Siswa</th>
      </tr>
    </thead>
    <tbody>
      ${Array.from({length:Math.max(X.length,Q.length)},(a,l)=>{const w=X[l],b=Q[l];return`<tr>
          <td class="num">${w?X.indexOf(w)+1+".":""}</td>
          <td class="kelas-cell">${w?w.kelas:""}</td>
          <td>${w?w.nama:""}</td>
          <td class="num">${b?Y+Q.indexOf(b)+1+".":""}</td>
          <td class="kelas-cell">${b?b.kelas:""}</td>
          <td>${b?b.nama:""}</td>
        </tr>`}).join("")}
    </tbody>
  </table>`}

  <!-- SISWA TIDAK HADIR -->
  <div class="section-title">Siswa Tidak Hadir</div>
  <table class="data-table">
    <thead>
      <tr>
        <th colspan="3" style="background:#fef2f2;">Sakit (S) — ${Z.length} siswa</th>
        <th colspan="3" style="background:#fefce8;">Izin (I) — ${ee.length} siswa</th>
        <th colspan="3" style="background:#fff7ed;">Alpa (A) — ${te.length} siswa</th>
      </tr>
      <tr>
        <th>No.</th><th>Kls</th><th>Nama</th>
        <th>No.</th><th>Kls</th><th>Nama</th>
        <th>No.</th><th>Kls</th><th>Nama</th>
      </tr>
    </thead>
    <tbody>
      ${Array.from({length:et},(a,l)=>{const w=Z[l],b=ee[l],D=te[l];return`<tr>
          <td class="num">${w?l+1+".":""}</td>
          <td class="kelas-cell">${w?w.kelas:""}</td>
          <td>${w?w.nama:""}</td>
          <td class="num">${b?l+1+".":""}</td>
          <td class="kelas-cell">${b?b.kelas:""}</td>
          <td>${b?b.nama:""}</td>
          <td class="num">${D?l+1+".":""}</td>
          <td class="kelas-cell">${D?D.kelas:""}</td>
          <td>${D?D.nama:""}</td>
        </tr>`}).join("")}
    </tbody>
  </table>

  <!-- KEJADIAN PENTING -->
  <div class="section-title">Kejadian Penting dan Tindak Lanjut</div>
  <table class="data-table" style="margin-bottom: 0;">
    <tbody>
      <tr><td style="height: 60pt;"></td></tr>
    </tbody>
  </table>

  <!-- TANDA TANGAN -->
  <table class="signature-table">
    <tr>
      <td>
        Mengetahui,<br>
        <strong>Kepala Sekolah</strong>
        <div class="signature-space"></div>
        <div>( <span class="signature-name"></span> )</div>
      </td>
      <td>
        Jakarta, ${V}<br>
        <strong>Koordinator Guru Piket</strong>
        <div class="signature-space"></div>
        <div>( <span class="signature-name">${Ze}</span> )</div>
      </td>
    </tr>
  </table>

</div>
</body>
</html>`,K=window.open("","_blank","width=900,height=700");if(!K){alert("Popup diblokir oleh browser. Izinkan popup untuk halaman ini.");return}K.document.write(tt),K.document.close(),K.focus(),setTimeout(()=>{K.print()},500)}catch(t){console.error("Laporan error:",t),alert("Gagal membuat laporan: "+t.message)}finally{xe(!1)}},[k,M]);if(He&&Ae.length===0)return e.jsx("div",{className:"flex justify-center items-center h-full",children:e.jsx("div",{className:"w-8 h-8 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"})});const Ye=({active:t,payload:s,label:n})=>t&&s&&s.length?e.jsxs("div",{className:"bg-slate-900 text-white text-xs px-3 py-2 rounded-2xl shadow-lg",children:[e.jsx("p",{className:"font-semibold mb-1",children:n}),e.jsxs("p",{className:"text-emerald-400",children:[s[0].value," Siswa Hadir"]})]}):null,Xe=({active:t,payload:s,label:n})=>t&&s&&s.length?e.jsxs("div",{className:"bg-slate-900 text-white text-xs px-3 py-2 rounded-2xl shadow-lg",children:[e.jsxs("p",{className:"font-semibold mb-1",children:["Kelas ",n]}),e.jsxs("p",{className:"text-indigo-400",children:[s[0].value," Siswa Hadir"]})]}):null;return e.jsxs("div",{className:"animate-fade-in font-sans text-slate-800 flex flex-col gap-6",children:[e.jsxs("div",{className:"flex items-center gap-2 bg-slate-100 p-1.5 rounded-2xl w-fit border border-slate-200",children:[e.jsxs("button",{type:"button",onClick:()=>ce("daily"),className:`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${q==="daily"?"bg-white text-indigo-700 shadow-sm ring-1 ring-slate-200":"text-slate-600 hover:text-slate-900"}`,children:[e.jsx("span",{children:"📅"}),e.jsx("span",{children:"Tampilan Harian (Per Hari)"})]}),e.jsxs("button",{type:"button",onClick:()=>ce("matrix"),className:`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${q==="matrix"?"bg-white text-indigo-700 shadow-sm ring-1 ring-slate-200":"text-slate-600 hover:text-slate-900"}`,children:[e.jsx("span",{children:"📊"}),e.jsx("span",{children:"Matriks Rekap Presensi (Bulanan & Koreksi Hardfile)"}),e.jsx("span",{className:"px-1.5 py-0.5 rounded-md text-[10px] font-black bg-indigo-100 text-indigo-700",children:"Baru"})]})]}),q==="matrix"?e.jsx(lt,{session:M,activeTa:j,initialKelas:x&&x.length>0?x[0]:"",onDataChanged:()=>{var t;return(t=y.current)==null?void 0:t.call(y,!0)}}):e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"flex flex-col sm:flex-row sm:items-center justify-between gap-4",children:[e.jsxs("div",{className:"hidden",children:[e.jsx("h2",{className:"text-2xl font-black text-slate-900 tracking-tight",children:"Dashboard Presensi"}),e.jsx("p",{className:"text-sm text-slate-500 font-medium mt-1",children:"Ringkasan harian dan statistik kehadiran siswa."})]}),e.jsxs("div",{className:"flex flex-wrap items-center gap-3",children:[(C==null?void 0:C.autAct)&&e.jsxs("div",{className:"hidden md:flex items-center gap-1.5 px-3 py-1.5 bg-violet-50 border border-violet-200 text-violet-700 text-xs font-semibold rounded-xl shrink-0",title:"Jadwal Otomatis Harian Aktif",children:[e.jsx("span",{children:"⏱️"}),e.jsxs("span",{children:["Jadwal: ",C.jamMulaiMasuk," - ",C.jamBatasPulang," (Pulang: ",C.jamMulaiPulang,")"]})]}),e.jsxs("button",{onClick:Re,disabled:pe,className:`px-3.5 py-2 text-xs font-bold rounded-xl transition-all shadow-sm flex items-center gap-2 shrink-0 ${R?"bg-emerald-600 hover:bg-emerald-700 text-white ring-2 ring-emerald-300":"bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300"}`,title:"Klik untuk membuka/menutup sesi presensi masuk (hadir) hari ini",children:[e.jsx("span",{className:`w-2 h-2 rounded-full ${R?"bg-white animate-pulse":"bg-rose-500"}`}),e.jsx("span",{children:pe?"Memproses...":R?"Sesi Masuk: AKTIF":"Buka Sesi Masuk"})]}),e.jsxs("button",{onClick:We,disabled:fe,className:`px-3.5 py-2 text-xs font-bold rounded-xl transition-all shadow-sm flex items-center gap-2 shrink-0 ${W?"bg-blue-600 hover:bg-blue-700 text-white ring-2 ring-blue-300":"bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300"}`,title:"Klik untuk membuka/menutup sesi presensi pulang siswa hari ini",children:[e.jsx("span",{className:"text-sm",children:W?"🏠":"🔒"}),e.jsx("span",{children:fe?"Memproses...":W?"Sesi Pulang: AKTIF":"Buka Sesi Pulang"})]}),e.jsxs("button",{onClick:Ve,disabled:J,className:"px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 text-white text-sm font-bold rounded-xl transition-colors shadow-sm flex items-center gap-2 shrink-0",children:[J?e.jsxs("svg",{className:"w-4 h-4 animate-spin",fill:"none",viewBox:"0 0 24 24",children:[e.jsx("circle",{className:"opacity-25",cx:"12",cy:"12",r:"10",stroke:"currentColor",strokeWidth:"4"}),e.jsx("path",{className:"opacity-75",fill:"currentColor",d:"M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"})]}):e.jsx("svg",{className:"w-4 h-4",fill:"none",viewBox:"0 0 24 24",stroke:"currentColor",strokeWidth:"2.5",children:e.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"})}),J?"Memuat...":"Laporan Harian"]}),e.jsxs("a",{href:"/presensi-manual-siswa",target:"_blank",rel:"noopener noreferrer",className:"px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold rounded-xl transition-colors shadow-sm flex items-center gap-2 shrink-0",children:[e.jsx("svg",{className:"w-4 h-4",fill:"none",viewBox:"0 0 24 24",stroke:"currentColor",strokeWidth:"2.5",children:e.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"})}),"Presensi Manual Siswa"]}),e.jsxs("a",{href:"/presensi-susulan-siswa",target:"_blank",rel:"noopener noreferrer",className:"px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white text-sm font-bold rounded-xl transition-all shadow-sm flex items-center gap-2 shrink-0",title:"Buka tab Presensi Susulan untuk siswa yang lupa presensi pagi (selalu dicatat Hadir)",children:[e.jsx("span",{children:"📝"}),e.jsx("span",{children:"Presensi Susulan Siswa"})]}),e.jsx("input",{type:"date",value:k,onChange:t=>$e(t.target.value),className:"px-4 py-2 bg-white border-none rounded-xl text-sm font-bold text-slate-700 focus:ring-2 focus:ring-indigo-500 outline-none shadow-sm cursor-pointer"})]})]}),e.jsxs("div",{className:"grid grid-cols-2 md:grid-cols-4 gap-4",children:[e.jsxs("div",{className:"bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4 transition-all hover:-translate-y-1 hover:shadow-md",children:[e.jsx("div",{className:"w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0",children:e.jsx("svg",{className:"w-6 h-6",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:e.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2",d:"M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"})})}),e.jsxs("div",{children:[e.jsx("p",{className:"text-xs font-semibold text-slate-500 mb-0.5",children:"Total Siswa"}),e.jsx("p",{className:"text-2xl font-black text-slate-800 leading-none",children:Oe})]})]}),e.jsxs("div",{className:"bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4 transition-all hover:-translate-y-1 hover:shadow-md relative overflow-hidden",children:[e.jsx("div",{className:"w-12 h-12 rounded-xl bg-emerald-50 text-emerald-500 flex items-center justify-center shrink-0 relative z-10",children:e.jsx("svg",{className:"w-6 h-6",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:e.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2",d:"M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"})})}),e.jsxs("div",{className:"relative z-10",children:[e.jsx("p",{className:"text-xs font-semibold text-slate-500 mb-0.5",children:"Hadir Hari Ini"}),e.jsx("p",{className:"text-2xl font-black text-emerald-600 leading-none",children:Fe})]}),e.jsx("div",{className:"absolute right-0 top-0 h-full w-2 bg-emerald-500"})]}),e.jsxs("div",{className:"bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4 transition-all hover:-translate-y-1 hover:shadow-md",children:[e.jsx("div",{className:"w-12 h-12 rounded-xl bg-orange-50 text-orange-500 flex items-center justify-center shrink-0",children:e.jsx("svg",{className:"w-6 h-6",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:e.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2",d:"M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"})})}),e.jsxs("div",{children:[e.jsx("p",{className:"text-xs font-semibold text-slate-500 mb-0.5",children:"Sakit / Izin"}),e.jsx("p",{className:"text-2xl font-black text-slate-800 leading-none",children:qe})]})]}),e.jsxs("div",{className:"bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4 transition-all hover:-translate-y-1 hover:shadow-md",children:[e.jsx("div",{className:"w-12 h-12 rounded-xl bg-rose-50 text-rose-500 flex items-center justify-center shrink-0",children:e.jsx("svg",{className:"w-6 h-6",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:e.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2",d:"M13 7a4 4 0 11-8 0 4 4 0 018 0zM9 14a6 6 0 00-6 6v1h12v-1a6 6 0 00-6-6zM21 12h-6"})})}),e.jsxs("div",{children:[e.jsx("p",{className:"text-xs font-semibold text-slate-500 mb-0.5",children:"Alpha"}),e.jsx("p",{className:"text-2xl font-black text-slate-800 leading-none",children:Ge})]})]})]}),e.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-3 gap-6",children:[e.jsxs("div",{className:"col-span-1 lg:col-span-2 bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col",children:[e.jsxs("div",{className:"flex justify-between items-center mb-6",children:[e.jsx("h3",{className:"font-bold text-slate-800",children:"Laporan Kehadiran Total"}),e.jsx("button",{className:"text-slate-400 hover:text-slate-600",children:e.jsx("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:e.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2",d:"M5 12h.01M12 12h.01M19 12h.01M6 12a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0z"})})})]}),e.jsx("div",{className:"flex-1 min-h-[250px] w-full",children:e.jsx(oe,{width:"100%",height:"100%",minWidth:0,minHeight:0,children:e.jsxs(it,{data:Je,margin:{top:5,right:10,left:-20,bottom:5},children:[e.jsx(Me,{strokeDasharray:"3 3",vertical:!1,stroke:"#f1f5f9"}),e.jsx(Le,{dataKey:"label",axisLine:!1,tickLine:!1,tick:{fontSize:11,fill:"#94a3b8"},dy:10}),e.jsx(De,{axisLine:!1,tickLine:!1,tick:{fontSize:11,fill:"#94a3b8"}}),e.jsx(de,{content:e.jsx(Ye,{})}),e.jsx(rt,{type:"monotone",dataKey:"total",stroke:"#10b981",strokeWidth:3,dot:{r:4,strokeWidth:2,fill:"#fff",stroke:"#10b981"},activeDot:{r:6,fill:"#10b981",stroke:"#fff",strokeWidth:2}})]})})})]}),e.jsxs("div",{className:"col-span-1 bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col",children:[e.jsxs("div",{className:"flex justify-between items-center mb-6",children:[e.jsx("h3",{className:"font-bold text-slate-800",children:"Kehadiran per Kelas"}),e.jsx("button",{className:"text-slate-400 hover:text-slate-600",children:e.jsx("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:e.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2",d:"M5 12h.01M12 12h.01M19 12h.01M6 12a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0z"})})})]}),e.jsx("div",{className:"flex-1 min-h-[250px] w-full",children:e.jsx(oe,{width:"100%",height:"100%",minWidth:0,minHeight:0,children:e.jsxs(ot,{data:Ue,margin:{top:5,right:10,left:-20,bottom:5},children:[e.jsx(Me,{strokeDasharray:"3 3",vertical:!1,stroke:"#f1f5f9"}),e.jsx(Le,{dataKey:"kelas",axisLine:!1,tickLine:!1,tick:{fontSize:11,fill:"#94a3b8"},dy:10}),e.jsx(De,{axisLine:!1,tickLine:!1,tick:{fontSize:11,fill:"#94a3b8"}}),e.jsx(de,{content:e.jsx(Xe,{}),cursor:{fill:"#f8fafc"}}),e.jsx(dt,{dataKey:"hadir",fill:"#6366f1",radius:[4,4,0,0],barSize:20})]})})})]})]}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-6",children:[e.jsxs("div",{className:"bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col",children:[e.jsxs("div",{className:"flex justify-between items-center mb-4",children:[e.jsx("h3",{className:"font-bold text-slate-800",children:"Total Perlu Perhatian"}),e.jsx("button",{className:"text-slate-400 hover:text-slate-600",children:e.jsx("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:e.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2",d:"M5 12h.01M12 12h.01M19 12h.01M6 12a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0z"})})})]}),v.length===0?e.jsxs("div",{className:"flex-1 flex flex-col items-center justify-center text-center p-4",children:[e.jsx("div",{className:"w-12 h-12 bg-slate-50 border border-slate-100 text-slate-400 rounded-full flex items-center justify-center mb-3",children:e.jsx("svg",{className:"w-6 h-6",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:e.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2",d:"M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"})})}),e.jsx("p",{className:"text-sm font-semibold text-slate-700",children:"Belum Ada Data"}),e.jsx("p",{className:"text-xs text-slate-500 mt-1",children:"Belum ada data presensi yang masuk hari ini."})]}):ve===0?e.jsxs("div",{className:"flex-1 flex flex-col items-center justify-center text-center p-4",children:[e.jsx("div",{className:"w-12 h-12 bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center mb-3",children:e.jsx("svg",{className:"w-6 h-6",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:e.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2",d:"M5 13l4 4L19 7"})})}),e.jsx("p",{className:"text-emerald-600 font-bold mb-1",children:"Aman Terkendali"}),e.jsx("p",{className:"text-slate-500 text-sm",children:"Tidak ada catatan Sakit, Izin, atau Alpha sejauh ini."})]}):e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"h-[180px] w-full relative",children:[e.jsx(oe,{width:"100%",height:"100%",minWidth:0,minHeight:0,children:e.jsxs(ht,{children:[e.jsx(mt,{data:O,cx:"50%",cy:"50%",innerRadius:50,outerRadius:75,paddingAngle:5,dataKey:"value",stroke:"none",children:O.map((t,s)=>e.jsx(ct,{fill:t.color},`cell-${s}`))}),e.jsx(de,{formatter:t=>[`${t} Siswa`,""],contentStyle:{borderRadius:"8px",border:"none",boxShadow:"0 4px 6px -1px rgb(0 0 0 / 0.1)"}})]})}),e.jsxs("div",{className:"absolute inset-0 flex items-center justify-center pointer-events-none flex-col",children:[e.jsx("span",{className:"text-2xl font-black text-slate-800 leading-none",children:ve}),e.jsx("span",{className:"text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1",children:"Siswa"})]})]}),e.jsx("div",{className:"mt-4 flex flex-wrap justify-center gap-x-4 gap-y-2",children:O.map((t,s)=>e.jsxs("div",{className:"flex items-center gap-1.5 text-xs font-semibold text-slate-600",children:[e.jsx("div",{className:"w-2.5 h-2.5 rounded-full",style:{backgroundColor:t.color}}),t.name," ",e.jsx("span",{className:"text-slate-400 font-bold ml-0.5",children:t.value})]},s))})]})]}),e.jsxs("div",{className:"bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col",children:[e.jsxs("div",{className:"flex justify-between items-center mb-4",children:[e.jsx("h3",{className:"font-bold text-slate-800",children:"Siswa Terajin (Minggu Ini)"}),e.jsx("button",{className:"text-slate-400 hover:text-slate-600",children:e.jsx("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:e.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2",d:"M5 12h.01M12 12h.01M19 12h.01M6 12a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0z"})})})]}),e.jsx("div",{className:"flex-1 overflow-y-auto pr-2 custom-scrollbar space-y-3 max-h-[220px]",children:ye.length===0?e.jsx("div",{className:"text-center text-slate-500 py-6 text-sm",children:"Belum ada data absensi yang mencukupi."}):ye.map((t,s)=>e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsxs("div",{className:"w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-xs font-bold text-slate-500 shrink-0 overflow-hidden relative border border-slate-200",children:[e.jsx("span",{className:"absolute z-0",children:we(t.nama)}),e.jsx("img",{src:`https://res.cloudinary.com/dwyhpysp5/image/upload/c_fill,w_100,h_100/SKL-BM/FOTO_${t.nisn}_${j==null?void 0:j.id}`,alt:t.nama,className:"w-full h-full object-cover relative z-10",onError:n=>{n.target.style.display="none"}})]}),e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsx("p",{className:"text-sm font-bold text-slate-800 truncate",children:t.nama}),e.jsxs("p",{className:"text-[11px] text-slate-500",children:["Kelas ",t.kelas]})]}),e.jsxs("div",{className:"text-right shrink-0 flex items-center gap-2",children:[e.jsxs("span",{className:"text-[11px] font-bold text-slate-400 bg-slate-50 px-1.5 py-0.5 rounded",children:[t.percentage,"%"]}),e.jsxs("span",{className:"text-xs font-bold text-emerald-600",children:[t.count," hr"]})]})]},t.nisn))})]}),e.jsxs("div",{className:"bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col",children:[e.jsxs("div",{className:"flex justify-between items-center mb-4",children:[e.jsx("h3",{className:"font-bold text-slate-800",children:"Siswa Belum Presensi"}),e.jsxs("div",{className:"bg-slate-100 text-slate-600 text-xs font-bold px-2 py-1 rounded-2xl",children:[U.length," Siswa"]})]}),e.jsx("div",{className:"flex-1 overflow-y-auto pr-2 custom-scrollbar space-y-3 max-h-[220px]",children:U.length===0?e.jsx("div",{className:"text-center text-slate-500 py-6 text-sm",children:"Semua siswa sudah dipresensi."}):U.sort((t,s)=>t.kelas.localeCompare(s.kelas)||t.nama_lengkap.localeCompare(s.nama_lengkap)).map((t,s)=>e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsxs("div",{className:"w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-xs font-bold text-slate-500 shrink-0 overflow-hidden relative border border-slate-200",children:[e.jsx("span",{className:"absolute z-0",children:we(t.nama_lengkap)}),e.jsx("img",{src:`https://res.cloudinary.com/dwyhpysp5/image/upload/c_fill,w_100,h_100/SKL-BM/FOTO_${t.nisn}_${j==null?void 0:j.id}`,alt:t.nama_lengkap,className:"w-full h-full object-cover relative z-10",onError:n=>{n.target.style.display="none"}})]}),e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsx("p",{className:"text-sm font-bold text-slate-800 truncate",children:t.nama_lengkap}),e.jsxs("p",{className:"text-[11px] text-slate-500",children:["Kls ",t.kelas]})]}),e.jsx("div",{className:"shrink-0",children:e.jsx("span",{className:"text-[10px] font-bold text-slate-400 bg-slate-50 border border-slate-200 px-2 py-1 rounded-md",children:"Belum Ada Data"})})]},`${t.nisn}-${s}`))})]})]})]}),e.jsx("style",{dangerouslySetInnerHTML:{__html:`
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background-color: #cbd5e1;
          border-radius: 10px;
        }
        .custom-scrollbar:hover::-webkit-scrollbar-thumb {
          background-color: #94a3b8;
        }
      `}})]})}export{Dt as default};
