const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BCRT3S4Y.js","assets/index-BXwKKKiV.js","assets/index-CQaq8uq7.css"])))=>i.map(i=>d[i]);
import{F as r,_ as t}from"./index-BXwKKKiV.js";const a=r("Share",{web:()=>t(()=>import("./web-BCRT3S4Y.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{a as S};
