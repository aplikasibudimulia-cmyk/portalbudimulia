const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-keJqDqEe.js","assets/index-DwfReJ8H.js","assets/index-CQaq8uq7.css"])))=>i.map(i=>d[i]);
import{F as r,_ as t}from"./index-DwfReJ8H.js";const a=r("Share",{web:()=>t(()=>import("./web-keJqDqEe.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{a as S};
