const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DTQr1isd.js","assets/index-CW35U0e-.js","assets/index-BcxVMJU7.css"])))=>i.map(i=>d[i]);
import{F as r,_ as t}from"./index-CW35U0e-.js";const a=r("Share",{web:()=>t(()=>import("./web-DTQr1isd.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{a as S};
