const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DOC4qc5M.js","assets/index-NMjYE8Pj.js","assets/index-EMuYlH21.css"])))=>i.map(i=>d[i]);
import{F as r,_ as t}from"./index-NMjYE8Pj.js";const a=r("Share",{web:()=>t(()=>import("./web-DOC4qc5M.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{a as S};
